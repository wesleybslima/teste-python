package internal

import (
	"fmt"
	"net/http"

	testerutils "github.com/codecrafters-io/tester-utils"
)

func testRespondWithUserAgent(stageHarness *testerutils.StageHarness) error {
	b := NewHTTPServerBinary(stageHarness)
	if err := b.Run(); err != nil {
		return err
	}

	logger := stageHarness.Logger
	client := NewHTTPClient()

	url := URL + "user-agent"
	userAgent := randomUserAgent()

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		logFriendlyError(logger, err)
		return fmt.Errorf("Could not create request: %v", err)
	}
	req.Header.Set("User-Agent", userAgent)

	resp, err := sendRequest(client, req, logger)
	if err != nil {
		return err
	}

	err = validateContent(*resp, userAgent)
	if err != nil {
		logFriendlyError(logger, err)
		return err
	}

	return nil
}
