#!/bin/sh
echo "hey, i exit immediately!"
