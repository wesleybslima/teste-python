#!/bin/sh
echo "hey, spawning a server"
exec python3 -m http.server 4221
