#!/bin/sh
echo "hey, i don't do anything but I take a while to exit!"
sleep 20
