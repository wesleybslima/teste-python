#!/bin/sh
exec "${TESTER_DIR}/tester"
